package praneeth.dining.problem;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Application {

	public static void main(String[] args) throws InterruptedException {
		
		ExecutorService service=null;
		Chopstick[] chopstick=null;
		Philosopher[] philosopher=null;
		
		try {
			chopstick=new Chopstick[Constants.NUMBER_OF_CHOPSTICKS];
			philosopher=new Philosopher[Constants.NUMBER_OF_PHILOSOPHERS];
			
			for(int i=0;i<Constants.NUMBER_OF_CHOPSTICKS;i++) {
				chopstick[i]=new Chopstick(i);
			}
			
			service=Executors.newFixedThreadPool(Constants.NUMBER_OF_PHILOSOPHERS);
			
			for(int i=0;i<Constants.NUMBER_OF_PHILOSOPHERS;i++) {
				philosopher[i]=new Philosopher(i,chopstick[i],chopstick[(i+1)%Constants.NUMBER_OF_PHILOSOPHERS]);
				service.execute(philosopher[i]);
			}
			
			Thread.sleep(Constants.SIMULATION_RUNNING_TIME);
			
			for(Philosopher phil: philosopher) {
				phil.setFull(true);
			}

		}finally {
			service.shutdown();
		}
		
		while(!service.isTerminated()) {
			Thread.sleep(1000);
		}
		
		for(Philosopher phil: philosopher) {
			System.out.println(phil+" has eaten "+phil.getEatingCounter()+" times");
		}
		
		
	}

}
