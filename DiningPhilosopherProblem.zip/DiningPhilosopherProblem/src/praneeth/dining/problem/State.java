package praneeth.dining.problem;

public enum State {
	LEFT, RIGHT;
}
